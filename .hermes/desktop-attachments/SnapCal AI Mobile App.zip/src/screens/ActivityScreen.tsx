import { useState } from 'react'

interface Activity {
  id: string
  type: string
  icon: string
  color: string
  time: string
  duration: number
  calories: number
  detail: string
}

const activityTypes = [
  { type: 'Running', icon: '🏃', color: 'var(--rose)' },
  { type: 'Walking', icon: '🚶', color: 'var(--green)' },
  { type: 'Gym', icon: '🏋️', color: 'var(--purple)' },
  { type: 'Cycling', icon: '🚴', color: 'var(--blue)' },
  { type: 'Swimming', icon: '🏊', color: 'var(--sky-500)' },
  { type: 'Yoga', icon: '🧘', color: 'var(--amber)' },
  { type: 'Football', icon: '⚽', color: 'var(--green)' },
  { type: 'Tennis', icon: '🎾', color: 'var(--orange)' },
  { type: 'Volleyball', icon: '🏐', color: 'var(--blue)' },
  { type: 'Water', icon: '💧', color: 'var(--blue)' },
  { type: 'Sleep', icon: '🌙', color: 'var(--purple)' },
  { type: 'Weight', icon: '⚖️', color: 'var(--rose)' },
]

const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
const todayIndex = 1 // Tuesday

const initialActivities: Activity[] = [
  { id: '1', type: 'Running', icon: '🏃', color: 'var(--rose)', time: '7:00 AM', duration: 35, calories: 312, detail: '5.2 km • Avg pace 6:44/km' },
  { id: '2', type: 'Walking', icon: '🚶', color: 'var(--green)', time: '12:30 PM', duration: 20, calories: 94, detail: '1.8 km • 2,840 steps' },
  { id: '3', type: 'Gym', icon: '🏋️', color: 'var(--purple)', time: '6:00 PM', duration: 55, calories: 280, detail: 'Upper body • Chest & triceps' },
]

interface AddActivityModalProps {
  onClose: () => void
  onAdd: (a: Activity) => void
}

function AddActivityModal({ onClose, onAdd }: AddActivityModalProps) {
  const [selectedType, setSelectedType] = useState(activityTypes[0])
  const [duration, setDuration] = useState('30')
  const [time, setTime] = useState('08:00')

  const handleAdd = () => {
    const cal = Math.round((Number(duration) * (selectedType.type === 'Running' ? 9 : selectedType.type === 'Gym' ? 5 : 4)))
    onAdd({
      id: Date.now().toString(),
      type: selectedType.type,
      icon: selectedType.icon,
      color: selectedType.color,
      time: time,
      duration: Number(duration),
      calories: cal,
      detail: `${duration} min session`,
    })
    onClose()
  }

  return (
    <div
      className="backdrop-in"
      style={{
        position: 'absolute',
        inset: 0,
        background: 'rgba(0,0,0,0.7)',
        zIndex: 50,
        display: 'flex',
        alignItems: 'flex-end',
      }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className="slide-up"
        style={{
          width: '100%',
          background: 'var(--bg-card)',
          borderRadius: '24px 24px 0 0',
          padding: '20px 20px 40px',
          maxHeight: '85%',
          overflowY: 'auto',
        }}
      >
        {/* Handle */}
        <div style={{ width: 36, height: 4, background: 'var(--border)', borderRadius: 2, margin: '0 auto 20px' }} />

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <h2 className="font-display" style={{ fontSize: 20, fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
            Log Activity
          </h2>
          <button
            onClick={onClose}
            style={{
              width: 32,
              height: 32,
              borderRadius: '50%',
              background: 'var(--bg-elevated)',
              border: 'none',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--text-secondary)',
            }}
          >
            ✕
          </button>
        </div>

        {/* Activity type selector */}
        <p style={{ fontSize: 12, color: 'var(--text-secondary)', fontWeight: 600, letterSpacing: '0.04em', margin: '0 0 10px' }}>
          ACTIVITY TYPE
        </p>
        <div
          className="no-scrollbar"
          style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 12, marginBottom: 20 }}
        >
          {activityTypes.map((a) => (
            <button
              key={a.type}
              onClick={() => setSelectedType(a)}
              style={{
                flexShrink: 0,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 4,
                padding: '10px 14px',
                background: selectedType.type === a.type ? a.color : 'var(--bg-elevated)',
                borderRadius: 14,
                border: selectedType.type === a.type ? 'none' : '1px solid var(--border)',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
            >
              <span style={{ fontSize: 20 }}>{a.icon}</span>
              <span
                style={{
                  fontSize: 11,
                  color: selectedType.type === a.type ? '#fff' : 'var(--text-secondary)',
                  whiteSpace: 'nowrap',
                  fontWeight: selectedType.type === a.type ? 600 : 400,
                }}
              >
                {a.type}
              </span>
            </button>
          ))}
        </div>

        {/* Duration & Time */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 }}>
          <div>
            <p style={{ fontSize: 12, color: 'var(--text-secondary)', fontWeight: 600, letterSpacing: '0.04em', margin: '0 0 8px' }}>
              DURATION (MIN)
            </p>
            <input
              type="number"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              style={{
                width: '100%',
                padding: '12px 14px',
                background: 'var(--bg-input)',
                border: '1px solid var(--border)',
                borderRadius: 12,
                color: 'var(--text-primary)',
                fontSize: 16,
                fontFamily: 'inherit',
                outline: 'none',
              }}
            />
          </div>
          <div>
            <p style={{ fontSize: 12, color: 'var(--text-secondary)', fontWeight: 600, letterSpacing: '0.04em', margin: '0 0 8px' }}>
              TIME
            </p>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              style={{
                width: '100%',
                padding: '12px 14px',
                background: 'var(--bg-input)',
                border: '1px solid var(--border)',
                borderRadius: 12,
                color: 'var(--text-primary)',
                fontSize: 16,
                fontFamily: 'inherit',
                outline: 'none',
              }}
            />
          </div>
        </div>

        {/* Estimated calories */}
        <div
          style={{
            padding: '12px 16px',
            background: 'var(--green-dim)',
            borderRadius: 12,
            border: '1px solid rgba(0,212,138,0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 20,
          }}
        >
          <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Estimated calories burned</span>
          <span className="font-display" style={{ fontSize: 18, fontWeight: 700, color: 'var(--green)' }}>
            ~{Math.round(Number(duration) * (selectedType.type === 'Running' ? 9 : 5))} kcal
          </span>
        </div>

        <button
          onClick={handleAdd}
          style={{
            width: '100%',
            padding: '16px',
            background: 'var(--green)',
            borderRadius: 16,
            border: 'none',
            color: '#fff',
            fontSize: 16,
            fontWeight: 700,
            cursor: 'pointer',
            fontFamily: 'inherit',
          }}
        >
          Log Activity
        </button>
      </div>
    </div>
  )
}

export default function ActivityScreen() {
  const [selectedDay, setSelectedDay] = useState(todayIndex)
  const [activities, setActivities] = useState<Activity[]>(initialActivities)
  const [showModal, setShowModal] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)

  const totalCalories = activities.reduce((s, a) => s + a.calories, 0)
  const totalDuration = activities.reduce((s, a) => s + a.duration, 0)

  const weekData = weekDays.map((d, i) => ({
    label: d,
    index: i,
    active: i <= todayIndex,
    steps: [6200, 8432, 4100, 9800, 7300, 5600, 0][i],
  }))

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)', position: 'relative' }}>
      {/* Header */}
      <div style={{ padding: '56px 20px 0', background: 'var(--bg-card)', borderBottom: '1px solid var(--border)', paddingBottom: 16 }}>
        <h1 className="font-display" style={{ fontSize: 26, fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 16px', letterSpacing: '-0.5px' }}>
          Activity
        </h1>

        {/* Week calendar */}
        <div style={{ display: 'flex', gap: 4 }}>
          {weekData.map((d) => (
            <button
              key={d.label}
              onClick={() => setSelectedDay(d.index)}
              style={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 6,
                padding: '8px 4px',
                background: selectedDay === d.index ? 'var(--green)' : 'transparent',
                borderRadius: 12,
                border: 'none',
                cursor: 'pointer',
                transition: 'background 0.2s ease',
              }}
            >
              <span
                style={{
                  fontSize: 11,
                  color: selectedDay === d.index ? '#fff' : 'var(--text-secondary)',
                  fontWeight: selectedDay === d.index ? 700 : 400,
                }}
              >
                {d.label}
              </span>
              <div
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 8,
                  background:
                    selectedDay === d.index
                      ? 'rgba(255,255,255,0.2)'
                      : d.active && d.index !== todayIndex
                      ? 'var(--green-dim)'
                      : 'var(--bg-elevated)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <span
                  className="font-display"
                  style={{
                    fontSize: 13,
                    fontWeight: 700,
                    color:
                      selectedDay === d.index
                        ? '#fff'
                        : d.active
                        ? 'var(--text-primary)'
                        : 'var(--text-muted)',
                  }}
                >
                  {d.index + 3}
                </span>
              </div>
              {/* Step bar */}
              <div style={{ width: '100%', height: 3, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
                <div
                  style={{
                    height: '100%',
                    width: `${(d.steps / 10000) * 100}%`,
                    background: selectedDay === d.index ? '#fff' : 'var(--green)',
                    borderRadius: 2,
                    opacity: d.active ? 1 : 0.2,
                  }}
                />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Summary strip */}
      <div
        className="no-scrollbar"
        style={{ display: 'flex', gap: 12, padding: '12px 20px', overflowX: 'auto', flexShrink: 0 }}
      >
        {[
          { label: 'Calories', value: `${totalCalories} kcal`, color: 'var(--orange)' },
          { label: 'Active Time', value: `${totalDuration} min`, color: 'var(--green)' },
          { label: 'Steps', value: '8,432', color: 'var(--rose)' },
          { label: 'Distance', value: '7.0 km', color: 'var(--blue)' },
        ].map((s) => (
          <div
            key={s.label}
            style={{
              flexShrink: 0,
              padding: '10px 14px',
              background: 'var(--bg-card)',
              borderRadius: 14,
              border: '1px solid var(--border)',
              minWidth: 90,
            }}
          >
            <p style={{ fontSize: 10, color: 'var(--text-secondary)', margin: 0, letterSpacing: '0.04em' }}>{s.label}</p>
            <p className="font-display" style={{ fontSize: 15, fontWeight: 700, color: s.color, margin: '3px 0 0' }}>
              {s.value}
            </p>
          </div>
        ))}
      </div>

      {/* Timeline */}
      <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '0 20px 100px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <h2 className="font-display" style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>
            Today's Timeline
          </h2>
          <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
            {activities.length} {activities.length === 1 ? 'activity' : 'activities'}
          </span>
        </div>

        {activities.length === 0 && (
          <div
            style={{
              textAlign: 'center',
              padding: '40px 20px',
              color: 'var(--text-muted)',
            }}
          >
            <div style={{ fontSize: 40, marginBottom: 12 }}>🎯</div>
            <p className="font-display" style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-secondary)', margin: '0 0 8px' }}>
              No activities yet
            </p>
            <p style={{ fontSize: 14, color: 'var(--text-muted)', margin: 0 }}>
              Tap + to log your first activity
            </p>
          </div>
        )}

        <div style={{ position: 'relative' }}>
          {activities.length > 0 && (
            <div
              style={{
                position: 'absolute',
                left: 19,
                top: 20,
                bottom: 20,
                width: 2,
                background: 'var(--border)',
              }}
            />
          )}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {activities.map((a) => (
              <div key={a.id} style={{ display: 'flex', gap: 12 }}>
                {/* Icon */}
                <div style={{ flexShrink: 0, position: 'relative', zIndex: 1 }}>
                  <div
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: '50%',
                      background: 'var(--bg-card)',
                      border: `2px solid ${a.color}`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 18,
                    }}
                  >
                    {a.icon}
                  </div>
                </div>
                {/* Card */}
                <div
                  style={{
                    flex: 1,
                    background: 'var(--bg-card)',
                    borderRadius: 18,
                    border: '1px solid var(--border)',
                    padding: '12px 14px',
                    boxShadow: 'var(--shadow-card)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
                      <span className="font-display" style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)' }}>
                        {a.type}
                      </span>
                      <span
                        style={{
                          padding: '2px 8px',
                          background: `${a.color}22`,
                          borderRadius: 6,
                          fontSize: 11,
                          color: a.color,
                          fontWeight: 600,
                        }}
                      >
                        {a.duration} min
                      </span>
                    </div>
                    <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: '2px 0 0' }}>{a.time} · {a.detail}</p>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ textAlign: 'right' }}>
                      <p className="font-display" style={{ fontSize: 16, fontWeight: 700, color: a.color, margin: 0 }}>
                        {a.calories}
                      </p>
                      <p style={{ fontSize: 10, color: 'var(--text-secondary)', margin: 0 }}>kcal</p>
                    </div>
                    <button
                      onClick={() => setActivities((prev) => prev.filter((x) => x.id !== a.id))}
                      style={{
                        width: 28,
                        height: 28,
                        borderRadius: '50%',
                        background: 'var(--rose-dim)',
                        border: 'none',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'var(--rose)',
                        fontSize: 12,
                      }}
                    >
                      ✕
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FAB */}
      <button
        onClick={() => setShowModal(true)}
        style={{
          position: 'absolute',
          bottom: 80,
          right: 20,
          width: 56,
          height: 56,
          borderRadius: '50%',
          background: 'var(--green)',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 4px 20px rgba(0,212,138,0.5)',
          zIndex: 10,
          transition: 'transform 0.2s ease',
        }}
        onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.1)')}
        onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
      >
        <svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2.5} strokeLinecap="round">
          <path d="M12 5v14M5 12h14" />
        </svg>
      </button>

      {showModal && (
        <AddActivityModal
          onClose={() => setShowModal(false)}
          onAdd={(a) => setActivities((prev) => [a, ...prev].sort((x, y) => x.time.localeCompare(y.time)))}
        />
      )}
    </div>
  )
}
