import { useState } from 'react'
import { useApp } from '../App'

type ProfileSection = 'main' | 'personal' | 'goals' | 'subscription' | 'settings' | 'faq' | 'support' | 'privacy' | 'terms'

function BackButton({ onBack }: { onBack: () => void }) {
  return (
    <button
      onClick={onBack}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        background: 'none',
        border: 'none',
        color: 'var(--green)',
        fontSize: 15,
        cursor: 'pointer',
        fontFamily: 'inherit',
        padding: 0,
        marginBottom: 16,
      }}
    >
      <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
        <path d="M19 12H5M12 5l-7 7 7 7" />
      </svg>
      Back
    </button>
  )
}

function PersonalInfoSection({ onBack }: { onBack: () => void }) {
  const fields = [
    { label: 'Full Name', value: 'Alex Johnson' },
    { label: 'Date of Birth', value: 'March 12, 1992' },
    { label: 'Gender', value: 'Male' },
    { label: 'Height', value: '178 cm' },
    { label: 'Current Weight', value: '85.0 kg' },
    { label: 'Target Weight', value: '75.0 kg' },
    { label: 'Email', value: 'alex.johnson@gmail.com' },
    { label: 'Phone', value: '+1 (555) 234-5678' },
  ]
  return (
    <div className="no-scrollbar" style={{ height: '100%', overflowY: 'auto', background: 'var(--bg)', padding: '56px 20px 24px' }}>
      <BackButton onBack={onBack} />
      <h1 className="font-display" style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 20px' }}>
        Personal Information
      </h1>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {fields.map((f) => (
          <div
            key={f.label}
            style={{
              padding: '14px 16px',
              background: 'var(--bg-card)',
              borderRadius: 16,
              border: '1px solid var(--border)',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>{f.label}</span>
            <span className="font-display" style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{f.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function GoalsSection({ onBack }: { onBack: () => void }) {
  const goals = [
    { label: 'Primary Goal', value: 'Fat Loss', icon: '🎯', color: 'var(--rose)' },
    { label: 'Daily Calories', value: '2,200 kcal', icon: '🔥', color: 'var(--orange)' },
    { label: 'Protein Target', value: '150g / day', icon: '🥩', color: 'var(--green)' },
    { label: 'Water Goal', value: '3.0 L / day', icon: '💧', color: 'var(--blue)' },
    { label: 'Sleep Target', value: '8 hours', icon: '🌙', color: 'var(--purple)' },
    { label: 'Steps Goal', value: '10,000 / day', icon: '👟', color: 'var(--amber)' },
    { label: 'Workout Frequency', value: '5× / week', icon: '💪', color: 'var(--rose)' },
    { label: 'Timeline', value: '6 months', icon: '📅', color: 'var(--green)' },
  ]
  return (
    <div className="no-scrollbar" style={{ height: '100%', overflowY: 'auto', background: 'var(--bg)', padding: '56px 20px 24px' }}>
      <BackButton onBack={onBack} />
      <h1 className="font-display" style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 20px' }}>
        My Goals
      </h1>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {goals.map((g) => (
          <div
            key={g.label}
            style={{
              padding: '14px 16px',
              background: 'var(--bg-card)',
              borderRadius: 16,
              border: '1px solid var(--border)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 10,
                  background: `${g.color}22`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                }}
              >
                {g.icon}
              </div>
              <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>{g.label}</span>
            </div>
            <span className="font-display" style={{ fontSize: 14, fontWeight: 700, color: g.color }}>{g.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function SubscriptionSection({ onBack }: { onBack: () => void }) {
  const [billing, setBilling] = useState<'monthly' | 'yearly'>('yearly')
  return (
    <div className="no-scrollbar" style={{ height: '100%', overflowY: 'auto', background: 'var(--bg)', padding: '56px 20px 24px' }}>
      <BackButton onBack={onBack} />
      <h1 className="font-display" style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 20px' }}>
        Subscription
      </h1>

      {/* Current plan */}
      <div
        style={{
          padding: '16px',
          background: 'linear-gradient(135deg, var(--purple) 0%, var(--blue) 100%)',
          borderRadius: 20,
          marginBottom: 20,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', margin: 0, letterSpacing: '0.06em' }}>CURRENT PLAN</p>
            <p className="font-display" style={{ fontSize: 22, fontWeight: 700, color: '#fff', margin: '4px 0 0' }}>Pro Annual</p>
          </div>
          <div
            style={{
              padding: '6px 12px',
              background: 'rgba(255,255,255,0.2)',
              borderRadius: 10,
              fontSize: 12,
              color: '#fff',
              fontWeight: 600,
            }}
          >
            Active ✓
          </div>
        </div>
        <div style={{ marginTop: 16, display: 'flex', gap: 16 }}>
          <div>
            <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.6)', margin: 0 }}>Price</p>
            <p className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#fff', margin: '2px 0 0' }}>$79 / year</p>
          </div>
          <div>
            <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.6)', margin: 0 }}>Renews</p>
            <p className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#fff', margin: '2px 0 0' }}>Aug 5, 2027</p>
          </div>
        </div>
      </div>

      {/* Features */}
      <div style={{ background: 'var(--bg-card)', borderRadius: 20, border: '1px solid var(--border)', padding: '16px', marginBottom: 20 }}>
        <p className="font-display" style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)', margin: '0 0 12px' }}>
          Included in Pro
        </p>
        {[
          '✦ Unlimited AI Coach conversations',
          '✦ Advanced nutrition analytics',
          '✦ 6-month transformation plans',
          '✦ Meal photo analysis',
          '✦ Priority support',
          '✦ 10% off Marketplace programs',
        ].map((f) => (
          <p key={f} style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 8px' }}>{f}</p>
        ))}
      </div>

      <button
        style={{
          width: '100%',
          padding: '14px',
          background: 'var(--bg-elevated)',
          borderRadius: 14,
          border: '1px solid var(--border)',
          color: 'var(--rose)',
          fontSize: 14,
          fontWeight: 600,
          cursor: 'pointer',
          fontFamily: 'inherit',
        }}
      >
        Cancel Subscription
      </button>
    </div>
  )
}

function SettingsSection({ onBack }: { onBack: () => void }) {
  const { darkMode, setDarkMode } = useApp()
  const [notifs, setNotifs] = useState(true)
  const [mealReminders, setMealReminders] = useState(true)
  const [units, setUnits] = useState<'metric' | 'imperial'>('metric')

  function Toggle({ value, onChange }: { value: boolean; onChange: () => void }) {
    return (
      <div
        onClick={onChange}
        style={{
          width: 46,
          height: 26,
          borderRadius: 13,
          background: value ? 'var(--green)' : 'var(--bg-elevated)',
          border: '1px solid var(--border)',
          position: 'relative',
          cursor: 'pointer',
          transition: 'background 0.2s ease',
          flexShrink: 0,
        }}
      >
        <div
          style={{
            position: 'absolute',
            top: 2,
            left: value ? 22 : 2,
            width: 20,
            height: 20,
            borderRadius: '50%',
            background: '#fff',
            transition: 'left 0.2s ease',
            boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
          }}
        />
      </div>
    )
  }

  return (
    <div className="no-scrollbar" style={{ height: '100%', overflowY: 'auto', background: 'var(--bg)', padding: '56px 20px 24px' }}>
      <BackButton onBack={onBack} />
      <h1 className="font-display" style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 20px' }}>
        Settings
      </h1>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {[
          { label: 'Dark Mode', toggle: true, value: darkMode, onChange: () => setDarkMode(!darkMode) },
          { label: 'Push Notifications', toggle: true, value: notifs, onChange: () => setNotifs(!notifs) },
          { label: 'Meal Reminders', toggle: true, value: mealReminders, onChange: () => setMealReminders(!mealReminders) },
        ].map((s) => (
          <div
            key={s.label}
            style={{
              padding: '14px 16px',
              background: 'var(--bg-card)',
              borderRadius: 16,
              border: '1px solid var(--border)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <span style={{ fontSize: 14, color: 'var(--text-primary)' }}>{s.label}</span>
            <Toggle value={s.value} onChange={s.onChange} />
          </div>
        ))}

        <div
          style={{
            padding: '14px 16px',
            background: 'var(--bg-card)',
            borderRadius: 16,
            border: '1px solid var(--border)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <span style={{ fontSize: 14, color: 'var(--text-primary)' }}>Units</span>
          <div style={{ display: 'flex', background: 'var(--bg-elevated)', borderRadius: 10, padding: 3, gap: 3 }}>
            {(['metric', 'imperial'] as const).map((u) => (
              <button
                key={u}
                onClick={() => setUnits(u)}
                style={{
                  padding: '5px 12px',
                  background: units === u ? 'var(--bg-card)' : 'transparent',
                  borderRadius: 8,
                  border: 'none',
                  color: units === u ? 'var(--text-primary)' : 'var(--text-muted)',
                  fontSize: 12,
                  fontWeight: units === u ? 600 : 400,
                  cursor: 'pointer',
                  fontFamily: 'inherit',
                  transition: 'all 0.2s ease',
                  textTransform: 'capitalize',
                }}
              >
                {u}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function SimpleTextSection({ title, onBack, content }: { title: string; onBack: () => void; content: string[] }) {
  return (
    <div className="no-scrollbar" style={{ height: '100%', overflowY: 'auto', background: 'var(--bg)', padding: '56px 20px 24px' }}>
      <BackButton onBack={onBack} />
      <h1 className="font-display" style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 20px' }}>
        {title}
      </h1>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {content.map((c, i) => (
          <p key={i} style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.7, margin: 0 }}>{c}</p>
        ))}
      </div>
    </div>
  )
}

export default function ProfileScreen() {
  const [section, setSection] = useState<ProfileSection>('main')
  const { darkMode, setDarkMode } = useApp()

  if (section === 'personal') return <PersonalInfoSection onBack={() => setSection('main')} />
  if (section === 'goals') return <GoalsSection onBack={() => setSection('main')} />
  if (section === 'subscription') return <SubscriptionSection onBack={() => setSection('main')} />
  if (section === 'settings') return <SettingsSection onBack={() => setSection('main')} />
  if (section === 'faq') return (
    <SimpleTextSection
      title="FAQ"
      onBack={() => setSection('main')}
      content={[
        'Q: How does SnapCal AI analyze food?\nA: Using advanced computer vision and a database of 2M+ foods, our AI identifies ingredients and calculates precise macros from photos.',
        'Q: Can I sync with Apple Health or Google Fit?\nA: Yes! SnapCal AI syncs with Apple Health, Google Fit, Garmin, Fitbit, and Whoop devices automatically.',
        'Q: How accurate is the calorie tracking?\nA: Our AI has 94% accuracy on photo analysis. You can always edit results before saving.',
        'Q: Can I use SnapCal offline?\nA: Core tracking works offline. AI features require an internet connection.',
      ]}
    />
  )
  if (section === 'support') return (
    <SimpleTextSection
      title="Support"
      onBack={() => setSection('main')}
      content={[
        'For support, contact us at support@snapcal.ai or use the in-app chat.',
        'Response time: Pro users receive priority support with responses within 2 hours. Free users within 24 hours.',
        'Community: Join 50,000+ members in our SnapCal community forum at community.snapcal.ai',
      ]}
    />
  )
  if (section === 'privacy') return (
    <SimpleTextSection
      title="Privacy Policy"
      onBack={() => setSection('main')}
      content={[
        'Last updated: August 1, 2026. SnapCal AI takes your privacy seriously.',
        'Data collected: We collect fitness data, food logs, and usage analytics to improve your experience. Your data is never sold to third parties.',
        'Data storage: All data is encrypted in transit and at rest using AES-256 encryption.',
        'Your rights: You may request deletion of your account and all associated data at any time through Settings > Account > Delete Account.',
      ]}
    />
  )
  if (section === 'terms') return (
    <SimpleTextSection
      title="Terms & Conditions"
      onBack={() => setSection('main')}
      content={[
        'By using SnapCal AI, you agree to these Terms of Service effective August 1, 2026.',
        'SnapCal AI is intended for informational and educational purposes. It is not a substitute for professional medical advice, diagnosis, or treatment.',
        'Subscriptions auto-renew unless cancelled 24 hours before the renewal date. Refunds are available within 30 days of purchase.',
        'Legal Disclaimer: The calorie and nutritional data provided are estimates. Individual results vary. Consult a healthcare provider before starting any fitness program.',
      ]}
    />
  )

  const menuItems = [
    { id: 'personal' as ProfileSection, icon: '👤', label: 'Personal Information', desc: 'Name, height, weight, contact' },
    { id: 'goals' as ProfileSection, icon: '🎯', label: 'Goals', desc: 'Targets, timeline, preferences' },
    { id: 'subscription' as ProfileSection, icon: '⭐', label: 'Subscription', desc: 'Pro Annual · Active', highlight: true },
    { id: 'settings' as ProfileSection, icon: '⚙️', label: 'Settings', desc: 'Notifications, display, units' },
    { id: 'faq' as ProfileSection, icon: '❓', label: 'FAQ', desc: 'Common questions answered' },
    { id: 'support' as ProfileSection, icon: '💬', label: 'Support', desc: 'Get help from our team' },
    { id: 'privacy' as ProfileSection, icon: '🔒', label: 'Privacy Policy', desc: 'How we handle your data' },
    { id: 'terms' as ProfileSection, icon: '📄', label: 'Terms & Conditions', desc: 'Legal · Disclaimer' },
  ]

  return (
    <div className="no-scrollbar" style={{ height: '100%', overflowY: 'auto', background: 'var(--bg)', paddingBottom: 24 }}>
      {/* Hero */}
      <div
        style={{
          padding: '56px 20px 24px',
          background: 'var(--bg-card)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        {/* Dark mode toggle */}
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 20 }}>
          <button
            onClick={() => setDarkMode(!darkMode)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '6px 12px',
              background: 'var(--bg-elevated)',
              border: '1px solid var(--border)',
              borderRadius: 20,
              color: 'var(--text-secondary)',
              fontSize: 12,
              cursor: 'pointer',
              fontFamily: 'inherit',
            }}
          >
            {darkMode ? '☀️ Light' : '🌙 Dark'}
          </button>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ position: 'relative' }}>
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&h=160&fit=crop&auto=format"
              alt="Alex"
              style={{ width: 72, height: 72, borderRadius: '50%', objectFit: 'cover', border: '3px solid var(--green)' }}
            />
            <div
              style={{
                position: 'absolute',
                bottom: 0,
                right: 0,
                width: 22,
                height: 22,
                borderRadius: '50%',
                background: 'var(--green)',
                border: '2px solid var(--bg-card)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 11,
              }}
            >
              ✏️
            </div>
          </div>
          <div>
            <h1 className="font-display" style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
              Alex Johnson
            </h1>
            <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '3px 0 0' }}>
              Member since March 2026
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
              <div
                style={{
                  padding: '3px 10px',
                  background: 'linear-gradient(135deg, var(--purple), var(--blue))',
                  borderRadius: 8,
                  fontSize: 11,
                  color: '#fff',
                  fontWeight: 700,
                }}
              >
                ⭐ Pro Member
              </div>
              <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>18-day streak 🔥</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginTop: 20 }}>
          {[
            { label: 'Weight Lost', value: '2.3 kg', color: 'var(--green)' },
            { label: 'Days Active', value: '18', color: 'var(--purple)' },
            { label: 'Health Score', value: '84%', color: 'var(--amber)' },
          ].map((s) => (
            <div
              key={s.label}
              style={{
                padding: '12px 10px',
                background: 'var(--bg-elevated)',
                borderRadius: 14,
                textAlign: 'center',
                border: '1px solid var(--border)',
              }}
            >
              <p className="font-display" style={{ fontSize: 20, fontWeight: 700, color: s.color, margin: 0 }}>
                {s.value}
              </p>
              <p style={{ fontSize: 10, color: 'var(--text-secondary)', margin: '3px 0 0' }}>{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Menu */}
      <div style={{ padding: '16px 20px 0' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setSection(item.id)}
              className="card-press"
              style={{
                width: '100%',
                padding: '14px 16px',
                background: 'var(--bg-card)',
                borderRadius: 18,
                border: item.highlight ? '1px solid rgba(123,110,246,0.4)' : '1px solid var(--border)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 14,
                textAlign: 'left',
                fontFamily: 'inherit',
                boxShadow: 'var(--shadow-card)',
              }}
            >
              <div
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 12,
                  background: item.highlight ? 'var(--purple-dim)' : 'var(--bg-elevated)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                  flexShrink: 0,
                }}
              >
                {item.icon}
              </div>
              <div style={{ flex: 1 }}>
                <p
                  className="font-display"
                  style={{
                    fontSize: 14,
                    fontWeight: 600,
                    color: item.highlight ? 'var(--purple)' : 'var(--text-primary)',
                    margin: 0,
                  }}
                >
                  {item.label}
                </p>
                <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: '2px 0 0' }}>{item.desc}</p>
              </div>
              <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" strokeWidth={2} strokeLinecap="round">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>
          ))}
        </div>

        {/* Sign out */}
        <button
          style={{
            width: '100%',
            padding: '14px',
            background: 'var(--rose-dim)',
            borderRadius: 16,
            border: '1px solid rgba(255,77,109,0.2)',
            color: 'var(--rose)',
            fontSize: 14,
            fontWeight: 600,
            cursor: 'pointer',
            fontFamily: 'inherit',
            marginTop: 16,
          }}
        >
          Sign Out
        </button>

        <p style={{ fontSize: 11, color: 'var(--text-muted)', textAlign: 'center', marginTop: 12 }}>
          SnapCal AI v2.4.1 · Made with ❤️ for your health
        </p>
      </div>
    </div>
  )
}
