import { useState, useEffect } from 'react'
import { useApp } from '../App'
import GoalPlanScreen from './GoalPlanScreen'
import MarketplaceScreen from './MarketplaceScreen'

interface CircularRingProps {
  value: number
  max: number
  size: number
  strokeWidth: number
  color: string
  trackColor?: string
}

function CircularRing({ value, max, size, strokeWidth, color, trackColor = 'rgba(255,255,255,0.06)' }: CircularRingProps) {
  const [mounted, setMounted] = useState(false)
  const r = (size - strokeWidth) / 2
  const circumference = 2 * Math.PI * r
  const pct = Math.min(value / max, 1)
  const offset = circumference - pct * circumference

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 100)
    return () => clearTimeout(t)
  }, [])

  return (
    <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={trackColor} strokeWidth={strokeWidth} />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeDasharray={circumference}
        strokeDashoffset={mounted ? offset : circumference}
        strokeLinecap="round"
        style={{ transition: 'stroke-dashoffset 1.4s cubic-bezier(0.4,0,0.2,1)' }}
      />
    </svg>
  )
}

function MiniProgressBar({ value, max, color }: { value: number; max: number; color: string }) {
  const [mounted, setMounted] = useState(false)
  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 200)
    return () => clearTimeout(t)
  }, [])
  const pct = Math.min((value / max) * 100, 100)
  return (
    <div style={{ height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
      <div
        style={{
          height: '100%',
          width: mounted ? `${pct}%` : '0%',
          background: color,
          borderRadius: 2,
          transition: 'width 1.2s cubic-bezier(0.4,0,0.2,1)',
        }}
      />
    </div>
  )
}

const metrics = [
  { label: 'Water', value: 1.8, max: 3.0, unit: 'L', color: 'var(--blue)', icon: '💧', key: 'water' },
  { label: 'Sleep', value: 7.2, max: 8, unit: 'h', color: 'var(--purple)', icon: '🌙', key: 'sleep' },
  { label: 'Protein', value: 112, max: 150, unit: 'g', color: 'var(--green)', icon: '🥩', key: 'protein' },
  { label: 'Carbs', value: 198, max: 250, unit: 'g', color: 'var(--amber)', icon: '🌾', key: 'carbs' },
  { label: 'Fat', value: 64, max: 73, unit: 'g', color: 'var(--orange)', icon: '🥑', key: 'fat' },
  { label: 'Steps', value: 8432, max: 10000, unit: '', color: 'var(--rose)', icon: '👟', key: 'steps' },
]

const meals = [
  {
    type: 'Breakfast',
    time: '8:30 AM',
    calories: 420,
    icon: '☀️',
    items: ['Oatmeal with blueberries', 'Greek yogurt', 'Black coffee'],
    macros: { p: 28, c: 62, f: 12 },
    logged: true,
  },
  {
    type: 'Lunch',
    time: '12:45 PM',
    calories: 680,
    icon: '🌤',
    items: ['Grilled chicken salad', 'Quinoa', 'Lemon dressing'],
    macros: { p: 52, c: 58, f: 22 },
    logged: true,
  },
  {
    type: 'Dinner',
    time: '7:00 PM',
    calories: 590,
    icon: '🌙',
    items: ['Salmon fillet', 'Steamed broccoli', 'Brown rice'],
    macros: { p: 48, c: 54, f: 18 },
    logged: true,
  },
  {
    type: 'Snacks',
    time: 'Throughout day',
    calories: 157,
    icon: '🍎',
    items: ['Apple', 'Almonds (20g)', 'Protein bar'],
    macros: { p: 12, c: 24, f: 8 },
    logged: false,
  },
]

export default function HomeScreen() {
  const { darkMode } = useApp()
  const [expandedMeal, setExpandedMeal] = useState<string | null>(null)
  const [showGoalPlan, setShowGoalPlan] = useState(false)
  const [showMarketplace, setShowMarketplace] = useState(false)

  const totalCalories = 1847
  const calorieGoal = 2200
  const healthScore = 84

  if (showGoalPlan) return <GoalPlanScreen onBack={() => setShowGoalPlan(false)} />
  if (showMarketplace) return <MarketplaceScreen onBack={() => setShowMarketplace(false)} />

  return (
    <div
      className="no-scrollbar"
      style={{
        height: '100%',
        overflowY: 'auto',
        background: 'var(--bg)',
        paddingBottom: 24,
      }}
    >
      {/* Header */}
      <div style={{ padding: '56px 20px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: 0, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
            Tuesday, August 5
          </p>
          <h1
            className="font-display"
            style={{ fontSize: 26, fontWeight: 700, color: 'var(--text-primary)', margin: '2px 0 0', letterSpacing: '-0.5px' }}
          >
            Good morning, Alex 👋
          </h1>
        </div>
        <button
          style={{
            width: 42,
            height: 42,
            borderRadius: '50%',
            background: 'var(--bg-elevated)',
            border: '1px solid var(--border)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            overflow: 'hidden',
          }}
        >
          <img
            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=84&h=84&fit=crop&auto=format"
            alt="Alex profile"
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        </button>
      </div>

      {/* Calorie Ring Hero */}
      <div
        style={{
          margin: '24px 20px 0',
          background: 'var(--bg-card)',
          borderRadius: 24,
          border: '1px solid var(--border)',
          padding: '24px 20px',
          boxShadow: 'var(--shadow-card)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          {/* Ring */}
          <div style={{ position: 'relative', flexShrink: 0 }}>
            <CircularRing value={totalCalories} max={calorieGoal} size={140} strokeWidth={12} color="var(--green)" />
            {/* Inner rings */}
            <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }}>
              <CircularRing value={112} max={150} size={108} strokeWidth={8} color="var(--purple)" />
            </div>
            <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }}>
              <CircularRing value={8432} max={10000} size={80} strokeWidth={6} color="var(--rose)" />
            </div>
            {/* Center text */}
            <div
              style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%,-50%)',
                textAlign: 'center',
              }}
            >
              <p className="font-display" style={{ fontSize: 20, fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                {totalCalories.toLocaleString()}
              </p>
              <p style={{ fontSize: 10, color: 'var(--text-secondary)', margin: 0 }}>kcal</p>
            </div>
          </div>

          {/* Stats */}
          <div style={{ flex: 1 }}>
            <div style={{ marginBottom: 16 }}>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: '0 0 2px' }}>Calorie Goal</p>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
                <span className="font-display" style={{ fontSize: 28, fontWeight: 700, color: 'var(--text-primary)', lineHeight: 1 }}>
                  {totalCalories.toLocaleString()}
                </span>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>/ {calorieGoal.toLocaleString()}</span>
              </div>
              <MiniProgressBar value={totalCalories} max={calorieGoal} color="var(--green)" />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {[
                { label: 'Protein', value: '112g', color: 'var(--purple)' },
                { label: 'Carbs', value: '198g', color: 'var(--amber)' },
                { label: 'Fat', value: '64g', color: 'var(--orange)' },
                { label: 'Steps', value: '8,432', color: 'var(--rose)' },
              ].map((s) => (
                <div key={s.label}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ width: 8, height: 8, borderRadius: '50%', background: s.color, flexShrink: 0 }} />
                    <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{s.label}</span>
                  </div>
                  <p className="font-display" style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', margin: '2px 0 0 14px' }}>
                    {s.value}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Health Score */}
        <div
          style={{
            marginTop: 20,
            padding: '12px 16px',
            background: 'var(--green-dim)',
            borderRadius: 14,
            border: '1px solid rgba(0,212,138,0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 20 }}>✦</span>
            <div>
              <p style={{ fontSize: 11, color: 'var(--green)', margin: 0, fontWeight: 500, letterSpacing: '0.04em' }}>HEALTH SCORE</p>
              <p className="font-display" style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', margin: 0, lineHeight: 1.2 }}>
                {healthScore}%
              </p>
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{ fontSize: 11, color: 'var(--text-secondary)', margin: 0 }}>Excellent today</p>
            <div style={{ display: 'flex', gap: 3, marginTop: 4, justifyContent: 'flex-end' }}>
              {Array.from({ length: 7 }).map((_, i) => (
                <div
                  key={i}
                  style={{
                    width: 6,
                    height: i < 6 ? 16 + i * 3 : 14,
                    background: i < 5 ? 'var(--green)' : 'var(--border)',
                    borderRadius: 2,
                    opacity: i < 5 ? 0.4 + i * 0.15 : 0.2,
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* View Full Plan */}
      <div style={{ padding: '16px 20px 0' }}>
        <button
          onClick={() => setShowGoalPlan(true)}
          className="card-press"
          style={{
            width: '100%',
            padding: '14px 20px',
            background: 'linear-gradient(135deg, var(--green) 0%, #00a86b 100%)',
            borderRadius: 16,
            border: 'none',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div style={{ textAlign: 'left' }}>
            <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', margin: 0, letterSpacing: '0.06em' }}>6-MONTH PLAN</p>
            <p className="font-display" style={{ fontSize: 16, fontWeight: 700, color: '#fff', margin: '2px 0 0' }}>
              View Full Transformation Plan
            </p>
          </div>
          <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} strokeLinecap="round">
            <path d="M5 12h14M12 5l7 7-7 7" />
          </svg>
        </button>
      </div>

      {/* Metric Cards */}
      <div style={{ padding: '20px 0 0' }}>
        <div style={{ padding: '0 20px 10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h2 className="font-display" style={{ fontSize: 17, fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>
            Today's Overview
          </h2>
        </div>
        <div
          className="no-scrollbar"
          style={{ display: 'flex', gap: 12, overflowX: 'auto', padding: '0 20px', paddingRight: 20 }}
        >
          {metrics.map((m) => (
            <div
              key={m.key}
              className="card-press"
              style={{
                flexShrink: 0,
                width: 110,
                background: 'var(--bg-card)',
                borderRadius: 18,
                border: '1px solid var(--border)',
                padding: '14px 14px 12px',
                boxShadow: 'var(--shadow-card)',
                cursor: 'pointer',
              }}
            >
              <div style={{ fontSize: 20, marginBottom: 8 }}>{m.icon}</div>
              <p className="font-display" style={{ fontSize: 20, fontWeight: 700, color: 'var(--text-primary)', margin: 0, lineHeight: 1 }}>
                {m.value.toLocaleString()}
                <span style={{ fontSize: 11, fontWeight: 400, color: 'var(--text-secondary)' }}>{m.unit}</span>
              </p>
              <p style={{ fontSize: 11, color: 'var(--text-secondary)', margin: '4px 0 8px' }}>{m.label}</p>
              <MiniProgressBar value={m.value} max={m.max} color={m.color} />
              <p style={{ fontSize: 10, color: 'var(--text-muted)', margin: '4px 0 0', textAlign: 'right' }}>
                / {m.max}{m.unit}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Today's Meals */}
      <div style={{ padding: '24px 20px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <h2 className="font-display" style={{ fontSize: 17, fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>
            Today's Meals
          </h2>
          <button style={{ fontSize: 13, color: 'var(--green)', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 500 }}>
            + Add
          </button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {meals.map((meal) => (
            <div
              key={meal.type}
              className="card-press"
              onClick={() => setExpandedMeal(expandedMeal === meal.type ? null : meal.type)}
              style={{
                background: 'var(--bg-card)',
                borderRadius: 18,
                border: '1px solid var(--border)',
                overflow: 'hidden',
                boxShadow: 'var(--shadow-card)',
                cursor: 'pointer',
              }}
            >
              <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 12,
                      background: meal.logged ? 'var(--green-dim)' : 'var(--bg-elevated)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 18,
                    }}
                  >
                    {meal.icon}
                  </div>
                  <div>
                    <p className="font-display" style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>
                      {meal.type}
                    </p>
                    <p style={{ fontSize: 12, color: 'var(--text-secondary)', margin: '2px 0 0' }}>{meal.time}</p>
                  </div>
                </div>
                <div style={{ textAlign: 'right', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div>
                    <p className="font-display" style={{ fontSize: 16, fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                      {meal.calories}
                    </p>
                    <p style={{ fontSize: 10, color: 'var(--text-secondary)', margin: 0 }}>kcal</p>
                  </div>
                  <svg
                    width={16}
                    height={16}
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="var(--text-muted)"
                    strokeWidth={2}
                    strokeLinecap="round"
                    style={{
                      transform: expandedMeal === meal.type ? 'rotate(180deg)' : 'rotate(0)',
                      transition: 'transform 0.3s ease',
                    }}
                  >
                    <path d="M6 9l6 6 6-6" />
                  </svg>
                </div>
              </div>

              {expandedMeal === meal.type && (
                <div style={{ borderTop: '1px solid var(--border)', padding: '12px 16px' }} className="fade-in">
                  <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                    {[
                      { label: 'P', value: meal.macros.p + 'g', color: 'var(--green)' },
                      { label: 'C', value: meal.macros.c + 'g', color: 'var(--amber)' },
                      { label: 'F', value: meal.macros.f + 'g', color: 'var(--orange)' },
                    ].map((m) => (
                      <div
                        key={m.label}
                        style={{
                          flex: 1,
                          padding: '6px 8px',
                          background: 'var(--bg-elevated)',
                          borderRadius: 10,
                          textAlign: 'center',
                        }}
                      >
                        <p style={{ fontSize: 10, color: m.color, margin: 0, fontWeight: 600 }}>{m.label}</p>
                        <p className="font-display" style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                          {m.value}
                        </p>
                      </div>
                    ))}
                  </div>
                  {meal.items.map((item) => (
                    <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                      <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--green)', flexShrink: 0 }} />
                      <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{item}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* AI Recommendation Card */}
      <div style={{ padding: '20px 20px 0' }}>
        <div
          style={{
            background: 'linear-gradient(135deg, #1a1040 0%, #0d1a2e 100%)',
            borderRadius: 22,
            border: '1px solid rgba(123,110,246,0.3)',
            padding: '20px',
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          {/* Glow blob */}
          <div
            style={{
              position: 'absolute',
              width: 120,
              height: 120,
              borderRadius: '50%',
              background: 'radial-gradient(circle, rgba(123,110,246,0.4) 0%, transparent 70%)',
              top: -20,
              right: -20,
            }}
          />
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: 8,
                background: 'var(--purple)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2} strokeLinecap="round">
                <circle cx="12" cy="12" r="10" />
                <path d="M12 8v4l3 3" />
              </svg>
            </div>
            <span style={{ fontSize: 11, color: 'var(--purple)', fontWeight: 600, letterSpacing: '0.06em' }}>AI INSIGHT</span>
          </div>
          <p className="font-display" style={{ fontSize: 15, fontWeight: 600, color: '#f0f4ff', margin: '0 0 8px', lineHeight: 1.4 }}>
            You're 353 kcal under goal today
          </p>
          <p style={{ fontSize: 13, color: 'rgba(240,244,255,0.6)', margin: '0 0 14px', lineHeight: 1.5 }}>
            Add a protein-rich evening snack — try cottage cheese with walnuts (≈180 kcal, 20g protein) to hit your macros.
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              style={{
                padding: '8px 16px',
                background: 'var(--purple)',
                borderRadius: 10,
                border: 'none',
                color: '#fff',
                fontSize: 13,
                fontWeight: 600,
                cursor: 'pointer',
                fontFamily: 'inherit',
              }}
            >
              Log Snack
            </button>
            <button
              style={{
                padding: '8px 16px',
                background: 'rgba(255,255,255,0.06)',
                borderRadius: 10,
                border: '1px solid rgba(255,255,255,0.1)',
                color: 'rgba(240,244,255,0.7)',
                fontSize: 13,
                cursor: 'pointer',
                fontFamily: 'inherit',
              }}
            >
              Ask AI Coach
            </button>
          </div>
        </div>
      </div>

      {/* Marketplace Preview */}
      <div style={{ padding: '24px 0 0' }}>
        <div style={{ padding: '0 20px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h2 className="font-display" style={{ fontSize: 17, fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>
            Expert Programs
          </h2>
          <button
            onClick={() => setShowMarketplace(true)}
            style={{ fontSize: 13, color: 'var(--green)', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 500 }}
          >
            See All
          </button>
        </div>
        <div className="no-scrollbar" style={{ display: 'flex', gap: 12, overflowX: 'auto', padding: '0 20px' }}>
          {featuredPrograms.map((p) => (
            <div
              key={p.name}
              className="card-press"
              style={{
                flexShrink: 0,
                width: 180,
                background: 'var(--bg-card)',
                borderRadius: 18,
                border: '1px solid var(--border)',
                overflow: 'hidden',
                boxShadow: 'var(--shadow-card)',
                cursor: 'pointer',
              }}
            >
              <div
                style={{
                  height: 110,
                  background: p.gradient,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 36,
                  position: 'relative',
                }}
              >
                {p.emoji}
                <div
                  style={{
                    position: 'absolute',
                    top: 8,
                    right: 8,
                    padding: '3px 8px',
                    background: 'rgba(0,0,0,0.5)',
                    borderRadius: 8,
                    fontSize: 11,
                    color: '#fff',
                    fontWeight: 600,
                  }}
                >
                  ${p.price}
                </div>
              </div>
              <div style={{ padding: '10px 12px' }}>
                <p className="font-display" style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>
                  {p.name}
                </p>
                <p style={{ fontSize: 11, color: 'var(--text-secondary)', margin: '3px 0 0' }}>{p.duration} weeks</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginTop: 6 }}>
                  <span style={{ color: 'var(--amber)', fontSize: 12 }}>★</span>
                  <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{p.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const featuredPrograms = [
  { name: 'Fat Burn Elite', duration: 12, price: 29, rating: '4.9', emoji: '🔥', gradient: 'linear-gradient(135deg,#ff4d6d,#ff7a45)' },
  { name: 'Yoga Flow Series', duration: 8, price: 19, rating: '4.8', emoji: '🧘', gradient: 'linear-gradient(135deg,#7b6ef6,#3dbbf7)' },
  { name: 'Muscle Builder', duration: 16, price: 39, rating: '4.7', emoji: '💪', gradient: 'linear-gradient(135deg,#00d48a,#0da8ed)' },
  { name: 'Home Shred', duration: 6, price: 14, rating: '4.6', emoji: '🏠', gradient: 'linear-gradient(135deg,#ffbe0b,#ff7a45)' },
]
