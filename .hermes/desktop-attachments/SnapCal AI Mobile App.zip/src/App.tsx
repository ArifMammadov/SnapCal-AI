import { useState, createContext, useContext } from 'react'
import HomeScreen from './screens/HomeScreen'
import ActivityScreen from './screens/ActivityScreen'
import AICoachScreen from './screens/AICoachScreen'
import StatisticsScreen from './screens/StatisticsScreen'
import ProfileScreen from './screens/ProfileScreen'

export type Tab = 'home' | 'activity' | 'coach' | 'stats' | 'profile'

interface AppContextType {
  darkMode: boolean
  setDarkMode: (v: boolean) => void
  activeTab: Tab
  setActiveTab: (t: Tab) => void
}

export const AppContext = createContext<AppContextType>({
  darkMode: true,
  setDarkMode: () => {},
  activeTab: 'home',
  setActiveTab: () => {},
})

export const useApp = () => useContext(AppContext)

export default function App() {
  const [darkMode, setDarkMode] = useState(true)
  const [activeTab, setActiveTab] = useState<Tab>('home')

  const navItems: { id: Tab; label: string; icon: string }[] = [
    { id: 'home', label: 'Home', icon: HomeIcon },
    { id: 'activity', label: 'Activity', icon: ActivityIcon },
    { id: 'coach', label: 'AI Coach', icon: CoachIcon },
    { id: 'stats', label: 'Stats', icon: StatsIcon },
    { id: 'profile', label: 'Profile', icon: ProfileIcon },
  ]

  return (
    <AppContext.Provider value={{ darkMode, setDarkMode, activeTab, setActiveTab }}>
      <div
        className={darkMode ? '' : 'light'}
        style={{ background: '#000', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      >
        {/* Phone Frame */}
        <div
          style={{
            width: '100%',
            maxWidth: 430,
            height: '100dvh',
            maxHeight: 932,
            background: 'var(--bg)',
            display: 'flex',
            flexDirection: 'column',
            position: 'relative',
            overflow: 'hidden',
            boxShadow: '0 0 80px rgba(0,0,0,0.8)',
          }}
        >
          {/* Screen content */}
          <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
            <ScreenTransition key={activeTab}>
              {activeTab === 'home' && <HomeScreen />}
              {activeTab === 'activity' && <ActivityScreen />}
              {activeTab === 'coach' && <AICoachScreen />}
              {activeTab === 'stats' && <StatisticsScreen />}
              {activeTab === 'profile' && <ProfileScreen />}
            </ScreenTransition>
          </div>

          {/* Bottom Navigation */}
          <div
            style={{
              background: 'var(--bg-card)',
              borderTop: '1px solid var(--border)',
              paddingBottom: 'env(safe-area-inset-bottom, 8px)',
              flexShrink: 0,
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', paddingTop: 8, paddingBottom: 4 }}>
              {navItems.map((item) => {
                const active = activeTab === item.id
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    style={{
                      flex: 1,
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: 4,
                      padding: '4px 0 6px',
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      position: 'relative',
                      WebkitTapHighlightColor: 'transparent',
                    }}
                  >
                    {/* Active pill */}
                    {active && (
                      <span
                        style={{
                          position: 'absolute',
                          top: 0,
                          left: '50%',
                          transform: 'translateX(-50%)',
                          width: 32,
                          height: 2.5,
                          background: 'var(--green)',
                          borderRadius: 0,
                          transition: 'all 0.3s ease',
                        }}
                      />
                    )}
                    <svg
                      width={22}
                      height={22}
                      viewBox="0 0 24 24"
                      fill="none"
                      style={{
                        color: active ? 'var(--green)' : 'var(--text-muted)',
                        transform: active ? 'scale(1.1)' : 'scale(1)',
                        transition: 'color 0.2s ease, transform 0.2s ease',
                      }}
                      dangerouslySetInnerHTML={{ __html: item.icon }}
                    />
                    <span
                      style={{
                        fontSize: 10,
                        fontWeight: active ? 600 : 400,
                        color: active ? 'var(--green)' : 'var(--text-muted)',
                        transition: 'color 0.2s ease',
                        letterSpacing: '0.02em',
                      }}
                    >
                      {item.label}
                    </span>
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </AppContext.Provider>
  )
}

function ScreenTransition({ children, key }: { children: React.ReactNode; key: string }) {
  return (
    <div
      className="screen-enter"
      style={{ height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}
    >
      {children}
    </div>
  )
}

// SVG icon paths as HTML strings
const HomeIcon = `
  <path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
  <path d="M9 21V12h6v9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
`
const ActivityIcon = `
  <path d="M22 12h-4l-3 9L9 3l-3 9H2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
`
const CoachIcon = `
  <path d="M12 2C6.48 2 2 6.48 2 12c0 1.85.5 3.58 1.38 5.07L2 22l5.07-1.38C8.42 21.5 10.15 22 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2z" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
  <path d="M8 10h.01M12 10h.01M16 10h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
`
const StatsIcon = `
  <path d="M18 20V10M12 20V4M6 20v-6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
`
const ProfileIcon = `
  <circle cx="12" cy="8" r="4" stroke="currentColor" strokeWidth="1.8"/>
  <path d="M4 20c0-4 3.58-7 8-7s8 3 8 7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
`
